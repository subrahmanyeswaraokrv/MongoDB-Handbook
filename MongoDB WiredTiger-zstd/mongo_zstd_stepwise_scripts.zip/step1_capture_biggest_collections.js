
const dbZstd = db.getSiblingDB("touprd_zstd");

const collections = dbZstd.getCollectionNames();
let statsList = [];

// Collect stats for all collections
collections.forEach(coll => {
    const stats = dbZstd.runCommand({ collStats: coll });
    statsList.push({
        collection: coll,
        storageSize: stats.storageSize,
        totalIndexSize: stats.totalIndexSize,
        count: stats.count
    });
});

// Sort by storageSize descending
statsList.sort((a, b) => b.storageSize - a.storageSize);

// Pick top 5
const topCollections = statsList.slice(0, 5);

// Print header
print("Top 5 Largest Collections in touprd_zstd (by storageSize)");
print("------------------------------------------------------------");

topCollections.forEach(stat => {
    const start = new Date();
    const docs = dbZstd[stat.collection].find({}).limit(1000).toArray();
    const duration = new Date() - start;

    printjson({
        collection: stat.collection,
        storageSize: stat.storageSize,
        totalIndexSize: stat.totalIndexSize,
        count: stat.count,
        queryTimeMs: duration
    });
});
