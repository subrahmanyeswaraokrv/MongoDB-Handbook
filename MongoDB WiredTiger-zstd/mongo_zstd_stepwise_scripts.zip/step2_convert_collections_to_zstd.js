
const dbZstd = db.getSiblingDB("touprd_zstd");
const collections = dbZstd.getCollectionNames();

collections.forEach(coll => {
  const tempColl = "tmp_" + coll;

  dbZstd[tempColl].drop();

  dbZstd.createCollection(tempColl, {
    storageEngine: {
      wiredTiger: {
        configString: "block_compressor=zstd"
      }
    }
  });

  dbZstd[coll].aggregate([{ $match: {} }, { $out: tempColl }]);

  const indexes = dbZstd[coll].getIndexes();
  indexes.forEach(idx => {
    if (idx.name !== "_id_") {
      dbZstd[tempColl].createIndex(idx.key, { name: idx.name });
    }
  });

  dbZstd[coll].drop();
  dbZstd[tempColl].renameCollection(coll);

  print(`✅ Converted ${coll} to ZSTD compression`);
});
